package dev.xkmc.glimmeringtales.init.data.spell.thunder;

import dev.xkmc.glimmeringtales.content.core.description.SpellTooltipData;
import dev.xkmc.glimmeringtales.content.engine.filter.InvulFrameFilter;
import dev.xkmc.glimmeringtales.init.GlimmeringTales;
import dev.xkmc.glimmeringtales.init.data.spell.NatureSpellBuilder;
import dev.xkmc.glimmeringtales.init.reg.GTItems;
import dev.xkmc.glimmeringtales.init.reg.GTRegistries;
import dev.xkmc.l2magic.content.engine.core.ConfiguredEngine;
import dev.xkmc.l2magic.content.engine.core.EntityProcessor;
import dev.xkmc.l2magic.content.engine.iterator.LinearIterator;
import dev.xkmc.l2magic.content.engine.logic.ListLogic;
import dev.xkmc.l2magic.content.engine.logic.ProcessorEngine;
import dev.xkmc.l2magic.content.engine.modifier.OffsetModifier;
import dev.xkmc.l2magic.content.engine.modifier.SetDirectionModifier;
import dev.xkmc.l2magic.content.engine.particle.SimpleParticleInstance;
import dev.xkmc.l2magic.content.engine.processor.CastAtProcessor;
import dev.xkmc.l2magic.content.engine.processor.DamageProcessor;
import dev.xkmc.l2magic.content.engine.processor.DelayedProcessor;
import dev.xkmc.l2magic.content.engine.processor.FilteredProcessor;
import dev.xkmc.l2magic.content.engine.selector.ApproxBallSelector;
import dev.xkmc.l2magic.content.engine.selector.SelectionType;
import dev.xkmc.l2magic.content.engine.sound.SoundInstance;
import dev.xkmc.l2magic.content.engine.spell.SpellAction;
import dev.xkmc.l2magic.content.engine.spell.SpellCastType;
import dev.xkmc.l2magic.content.engine.spell.SpellTriggerType;
import dev.xkmc.l2magic.content.engine.variable.DoubleVariable;
import dev.xkmc.l2magic.content.engine.variable.IntVariable;
import dev.xkmc.l2magic.content.entity.core.ProjectileConfig;
import dev.xkmc.l2magic.content.entity.engine.CustomProjectileShoot;
import dev.xkmc.l2magic.content.entity.motion.SimpleMotion;
import dev.xkmc.l2magic.init.registrate.EngineRegistry;
import net.minecraft.Util;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.phys.Vec3;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ChargeLink {

	public static final NatureSpellBuilder BUILDER = GTRegistries.THUNDER
			.build(GlimmeringTales.loc("charge_link")).focusAndCost(100, 600).mob(16, 1)
			.damageCustom(msg -> new DamageType(msg, 0.1f),
					"%s is electrocuted by charge link",
					"%s is electrocuted by %s with charge link",
					DamageTypeTags.IS_LIGHTNING)
			.projectile(ChargeLink::proj)
			.spell(ctx -> new SpellAction(gen(ctx), GTItems.CHARGE_LINK.get(), 2002,
					SpellCastType.INSTANT, SpellTriggerType.FACING_FRONT)
			).lang("Charge Link").desc(
					"[Ranged] Create",//TODO
					"Create",//TODO
					SpellTooltipData.of(EngineRegistry.DAMAGE)
			).graph(Thunderstorm.BUILDER);

	private static final DoubleVariable STRIKE = DoubleVariable.of("5");

	public static ProjectileConfig proj(NatureSpellBuilder ctx) {
		return ProjectileConfig.builder(SelectionType.ENEMY_NO_FAMILY)
				.tick(new SimpleParticleInstance(ParticleTypes.END_ROD, DoubleVariable.ZERO))
				.hit(new DamageProcessor(ctx.damage(), STRIKE, true, false))
				.hit(hitRoot(ctx))
				.size(DoubleVariable.of("0.5"))
				.motion(SimpleMotion.ZERO)
				.build();
	}

	private static ConfiguredEngine<?> gen(NatureSpellBuilder ctx) {
		return new ListLogic(List.of(
				new SoundInstance(
						SoundEvents.TRIDENT_THUNDER.value(),
						DoubleVariable.of("1"),
						DoubleVariable.of("1+rand(-0.1,0.1)+rand(-0.1,0.1)")
				), new CustomProjectileShoot(
						DoubleVariable.of("2"),
						ctx.proj,
						IntVariable.of("rand(30,35)"),
						false, false,
						Map.of()
				).move(OffsetModifier.of("0", "-0.2", "0"))
		));
	}

	private static EntityProcessor<?> hitRoot(NatureSpellBuilder ctx) {
		var recenter = Map.of(
				"mx", DoubleVariable.of("PosX"),
				"my", DoubleVariable.of("PosY"),
				"mz", DoubleVariable.of("PosZ")
		);
		var dmg = new DelayedProcessor(IntVariable.of("1"), new DamageProcessor(ctx.damage(), STRIKE, true, false));
		EntityProcessor<?> link = link(4, new SimpleParticleInstance(ParticleTypes.END_ROD, DoubleVariable.ZERO));
		var invul = new InvulFrameFilter(IntVariable.of("0"));
		var range = DoubleVariable.of("6");
		return new CastAtProcessor(
				CastAtProcessor.PosType.CENTER,
				CastAtProcessor.DirType.UP,
				new ProcessorEngine(
						SelectionType.ENEMY_NO_FAMILY,
						new ApproxBallSelector(range),
						List.of(new FilteredProcessor(invul, List.of(link, dmg, new CastAtProcessor(
										CastAtProcessor.PosType.CENTER,
										CastAtProcessor.DirType.UP,
								new ProcessorEngine(
										SelectionType.ENEMY_NO_FAMILY,
										new ApproxBallSelector(range),
										List.of(new FilteredProcessor(invul, List.of(link, dmg), List.of()))
								).delay(IntVariable.of("3")).withVariables(recenter)
						)), List.of()))
				).delay(IntVariable.of("2")).withVariables(recenter)
		);
	}

	private static EntityProcessor<?> link(double density, ConfiguredEngine<?> ins) {
		return new CastAtProcessor(
				CastAtProcessor.PosType.CENTER,
				CastAtProcessor.DirType.UP,
				new LinearIterator(
						DoubleVariable.of("step"), Vec3.ZERO, DoubleVariable.ZERO,
						IntVariable.of("count"), false, ins, null
				).move(new SetDirectionModifier(
						DoubleVariable.of("mx-PosX"),
						DoubleVariable.of("my-PosY"),
						DoubleVariable.of("mz-PosZ"))
				).withVariables(Util.make(new LinkedHashMap<>(), map -> {
							map.put("step", DoubleVariable.of("dist/count"));
							map.put("count", DoubleVariable.of("floor(dist*" + density + ")+1"));
							map.put("dist", DoubleVariable.of("sqrt((mx-PosX)^2+(my-PosY)^2+(mz-PosZ)^2)"));
						}
				))
		);
	}


}
