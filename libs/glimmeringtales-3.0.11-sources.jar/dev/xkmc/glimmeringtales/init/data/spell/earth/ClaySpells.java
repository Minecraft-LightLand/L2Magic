package dev.xkmc.glimmeringtales.init.data.spell.earth;

import dev.xkmc.glimmeringtales.content.core.description.SpellTooltipData;
import dev.xkmc.glimmeringtales.content.core.spell.BlockSpell;
import dev.xkmc.glimmeringtales.content.core.spell.RuneBlock;
import dev.xkmc.glimmeringtales.init.GlimmeringTales;
import dev.xkmc.glimmeringtales.init.data.spell.NatureSpellBuilder;
import dev.xkmc.glimmeringtales.init.reg.GTItems;
import dev.xkmc.glimmeringtales.init.reg.GTRegistries;
import dev.xkmc.l2magic.content.engine.block.ScheduleTick;
import dev.xkmc.l2magic.content.engine.block.SetBlock;
import dev.xkmc.l2magic.content.engine.core.ConfiguredEngine;
import dev.xkmc.l2magic.content.engine.core.ContextPredicate;
import dev.xkmc.l2magic.content.engine.core.IPredicate;
import dev.xkmc.l2magic.content.engine.logic.ListLogic;
import dev.xkmc.l2magic.content.engine.predicate.BlockInRangePredicate;
import dev.xkmc.l2magic.content.engine.predicate.BlockTestCondition;
import dev.xkmc.l2magic.content.engine.predicate.SurfaceBelowCondition;
import dev.xkmc.l2magic.content.engine.sound.SoundInstance;
import dev.xkmc.l2magic.content.engine.variable.DoubleVariable;
import dev.xkmc.l2magic.content.engine.variable.IntVariable;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.block.Blocks;

import java.util.List;

public class ClaySpells {

	public static final NatureSpellBuilder BUILDER = GTRegistries.EARTH
			.build(GlimmeringTales.loc("clay")).focusAndCost(60, 180)
			.grounded()
			.block(ClaySpells::gen, ClaySpells::cond, GTItems.RUNE_CLAY, RuneBlock::of,
					(b, e) -> b.add(Blocks.CLAY, BlockSpell.of(e)),
					(b, e) -> b.add(GTItems.CLAY_CARPET, BlockSpell.of(e))
			).lang("Clay Overflow").desc(
					"[Block] Form a circular carpet to trap entities",
					"Create a circular field of clay carpet lasting 5 seconds to immobilize entities",
					SpellTooltipData.of()
			).graph(QuartzSpells.BUILDER);

	private static ConfiguredEngine<?> gen(NatureSpellBuilder ctx) {
		return new ListLogic(List.of(
				new SoundInstance(
						SoundEvents.GRAVEL_HIT,
						DoubleVariable.of("0.5"),
						DoubleVariable.of("1+rand(-0.1,0.1)+rand(-0.1,0.1)")
				),
				new SetBlock(GTItems.CLAY_CARPET.getDefaultState()),
				new ScheduleTick(IntVariable.of("rand(80,120)"), GTItems.CLAY_CARPET.get())
		)).circular("4", "2", "2", null,
				SurfaceBelowCondition.full(),
				BlockTestCondition.Type.REPLACEABLE.get()
		);
	}

	private static IPredicate cond(NatureSpellBuilder ctx) {
		return BlockInRangePredicate.circular("4", "2", "8", null,
				SurfaceBelowCondition.full(),
				BlockTestCondition.Type.REPLACEABLE.get()
		);
	}

}
