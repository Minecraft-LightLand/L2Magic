package dev.xkmc.glimmeringtales.init.data.spell.earth;

import dev.xkmc.glimmeringtales.content.core.description.SpellTooltipData;
import dev.xkmc.glimmeringtales.content.core.spell.ResearchBonus;
import dev.xkmc.glimmeringtales.content.engine.instance.GTKnockBlock;
import dev.xkmc.glimmeringtales.content.research.core.ResearchDependency;
import dev.xkmc.glimmeringtales.init.GlimmeringTales;
import dev.xkmc.glimmeringtales.init.data.spell.NatureSpellBuilder;
import dev.xkmc.glimmeringtales.init.data.spell.life.VinesSpell;
import dev.xkmc.glimmeringtales.init.reg.GTItems;
import dev.xkmc.glimmeringtales.init.reg.GTRegistries;
import dev.xkmc.l2magic.content.engine.core.ConfiguredEngine;
import dev.xkmc.l2magic.content.engine.core.IPredicate;
import dev.xkmc.l2magic.content.engine.iterator.DelayedIterator;
import dev.xkmc.l2magic.content.engine.iterator.RingIterator;
import dev.xkmc.l2magic.content.engine.logic.ListLogic;
import dev.xkmc.l2magic.content.engine.logic.ProcessorEngine;
import dev.xkmc.l2magic.content.engine.modifier.OffsetModifier;
import dev.xkmc.l2magic.content.engine.particle.DustParticleInstance;
import dev.xkmc.l2magic.content.engine.predicate.BlockInRangePredicate;
import dev.xkmc.l2magic.content.engine.predicate.BlockTestCondition;
import dev.xkmc.l2magic.content.engine.processor.DamageProcessor;
import dev.xkmc.l2magic.content.engine.selector.ApproxBallSelector;
import dev.xkmc.l2magic.content.engine.selector.SelectionType;
import dev.xkmc.l2magic.content.engine.sound.SoundInstance;
import dev.xkmc.l2magic.content.engine.spell.SpellCastType;
import dev.xkmc.l2magic.content.engine.spell.SpellTriggerType;
import dev.xkmc.l2magic.content.engine.variable.BooleanVariable;
import dev.xkmc.l2magic.content.engine.variable.ColorVariable;
import dev.xkmc.l2magic.content.engine.variable.DoubleVariable;
import dev.xkmc.l2magic.content.engine.variable.IntVariable;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageType;

import java.util.List;

public class Earthquake {

	public static final NatureSpellBuilder BUILDER = GTRegistries.EARTH
			.build(GlimmeringTales.loc("earthquake")).focusAndCost(80, 480)
			.mob(7, 0.5, 0, 30)
			.grounded()
			.damageCustom(e -> new DamageType(e, 0.1f),
					"%s is killed by earthquake", "%s is killed by %s using earthquake",
					DamageTypeTags.IS_EXPLOSION
			).spell(Earthquake::gen, GTItems.EARTHQUAKE,
					SpellCastType.INSTANT, SpellTriggerType.SELF_POS, Earthquake::cond
			).lang("Earthquake").desc(
					"[Surrounding] Shake the ground and throw blocks into air",
					"Create earthquake dealing dealing %s, then throw blocks around you into the air that deals %s on fall",
					SpellTooltipData.damageAndFalling()
			).graph(VinesSpell.BUILDER.asParent(ResearchDependency.Type.BRANCH),
					ResearchBonus.small4(19), "L->E", "E->F", "F->S", "S->O", "O->T", "T->L");

	private static final DoubleVariable DMG = DoubleVariable.of("10");
	private static final DoubleVariable INIT = DoubleVariable.of("10");
	private static final DoubleVariable MAX = DoubleVariable.of("30");

	private static ConfiguredEngine<?> gen(NatureSpellBuilder ctx) {
		return new ListLogic(List.of(
				new SoundInstance(
						SoundEvents.GENERIC_EXPLODE.value(),
						DoubleVariable.of("2"),
						DoubleVariable.of("1+rand(-0.1,0.1)+rand(-0.1,0.1)")
				),
				new DelayedIterator(
						IntVariable.of("6"),
						IntVariable.of("2"),
						new ProcessorEngine(
								SelectionType.ENEMY_NO_FAMILY,
								new ApproxBallSelector(DoubleVariable.of("i+1")),
								List.of(new DamageProcessor(ctx.damage(), INIT, true, false))
						), "i"
				),
				new GTKnockBlock(DoubleVariable.of("1"), DMG, MAX).delay(IntVariable.of("i_r*2")
				).circular("8", "3", "0", "i",
						BooleanVariable.of("i_r>1.5"),
						BlockTestCondition.Type.BLOCKS_MOTION.get(),
						BlockTestCondition.Type.PUSHABLE.get(),
						BlockTestCondition.Type.REPLACEABLE.get().move(OffsetModifier.ABOVE))
		)).mobCastDelay(new DelayedIterator(IntVariable.of("3"), IntVariable.of("5"), new RingIterator(
				DoubleVariable.of("i+6"), IntVariable.of("64+32*i"), false, new DustParticleInstance(
				ColorVariable.Static.of(0x4f4f4f), DoubleVariable.of("0.5"), DoubleVariable.ZERO, IntVariable.of("20")
		)), "i").move(OffsetModifier.ABOVE));

	}

	private static IPredicate cond(NatureSpellBuilder ctx) {
		return BlockInRangePredicate.circular("5", "3", "8", "i",
				BooleanVariable.of("i_r>1.5"),
				BlockTestCondition.Type.BLOCKS_MOTION.get(),
				BlockTestCondition.Type.PUSHABLE.get(),
				BlockTestCondition.Type.REPLACEABLE.get().move(OffsetModifier.ABOVE)
		);
	}


}
